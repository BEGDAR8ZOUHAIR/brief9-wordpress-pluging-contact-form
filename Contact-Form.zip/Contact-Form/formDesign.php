
<?php
function insertcont()
{
    global $wpdb;

    if(isset($_POST['sub'])){

        // die(print_r($_POST['name']));
        // if( !empty($_POST['name']) || !empty($_POST['email']) || !empty($_POST['subject']) || !empty($_POST['message']))
        //     {
                
                // $connection = mysqli_connect('localhost','root','');
                // mysqli_select_db($connection,"brief_9_wordpress_3");

                $name = $_POST['fname'];
                $email = $_POST['lname'];
                $subj = $_POST['subject'];
                $mess = $_POST['msg'];

                // $name = "fjjfj";
                // $email = "jdjddj";
                // $subj ="djdjdj";
                // $mess = "jdjdj";

                $query="INSERT INTO contact (name,email,subject,message) VALUES ('$name','$email','$subj','$mess')";
                $wpdb->query($query);
                
            //     mysqli_query($connection,$query);
            // }else{
            //     echo '<h1 style="color:red;"> All fields are required</h1>';
            // }
    }
    else{
                echo '<h1 style="color:red;"> All fields are required</h1>';
            }
    
}



    
?>
<h2>Contact Us</h2>
<!-- 
<form method="post"  >
    <label class="mt-2" for="name">Name</label><br>
    <input type="text" name="name" id="name" placeholder="Name" class="w-100"><br>

    <label class="mt-2" for="email">Email</label><br>
    <input type="text" name="email" id="email" placeholder="Email" class="w-100"><br>

    <label class="mt-2" for="subject">Subject</label><br>
    <input type="text" name="subject" id="subject" placeholder="Subject" class="w-100"><br>

    <label class="mt-2" for="message">Message :</label><br>
    <textarea name="message"   placeholder="Your Message"></textarea><br>
    
    
    <input type="submit" class="mt-2" name="send" value="Send Message"  />
       

</form> -->

<form action="" method="post" enctype="multipart/form-data" onsubmit="<?php insertcont() ?> ">
  <label class="mt-2" for="fname">Full Name:</label><br>
  <input type="text" id="fname" name="fname" class="w-100"><br>

  <label class="mt-2" for="lname">Email:</label><br>
  <input type="email" id="lname" name="lname" class="w-100"><br>

  <label class="mt-2" for="subject">Subject:</label><br>
  <input type="text" id="subject" name="subject" class="w-100"><br>

  <label class="mt-2" for="msg">Message:</label><br>
  <textarea type="text" id="msg" name="msg" class="w-100"></textarea> <br>

  <input type="submit" class="mt-3" value="Send Message" name="sub"> 
</form>


